import { ListingPage } from "./ListingPage/ListingPage";

export const Home = () => {
  return (
    <div>
      <ListingPage />
    </div>
  );
};
