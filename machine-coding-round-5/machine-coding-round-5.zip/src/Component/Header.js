import { NavLink } from "react-router-dom";

export const Header = () => {
  return (
    <>
      <NavLink to="/">Home</NavLink>
    </>
  );
};
